from django.apps import AppConfig


class MyContactDataConfig(AppConfig):
    name = 'my_contact_data'
